// app/blog/[slug]/page.tsx

import { notFound } from "next/navigation";
import groq from "groq";
import { client } from "@/lib/sanity";
import CommentFormWrapper from "@/components/CommentFormWrapper";
import { LikeButton } from "@/components/LikeButton";
import BlogContent from "@/components/BlogContent";
import ShareButtons from "@/components/ShareButtons";
import type { Block } from "@/types/block";

export const revalidate = 0;

type BlogPost = {
  _id: string;
  title: string;
  summary: string;
  publishedAt: string;
  coverImage?: string;
  heroImage?: string;
  content: Block[];
  likes?: number;
  author?: {
    name: string;
    image?: string;
    bio?: string;
  };
  tags?: string[];
};

type Comment = {
  _id: string;
  name: string;
  comment: string;
  _createdAt: string;
};

type Journey = {
  _id: string;
  title: string;
  slug: { current: string };
  region?: { title: string };
  heroImage?: { asset: { url: string }; alt?: string };
};

type LikedBlog = {
  _id: string;
  title: string;
  slug: { current: string };
  coverImage?: string;
  alt?: string;
  likes?: number;
};

export async function generateStaticParams() {
  const slugs = await client.fetch(
    groq`*[_type == "blog" && defined(slug.current)]{ "slug": slug.current }`
  );
  return slugs.map((s: { slug: string }) => ({ slug: s.slug }));
}

async function getPost(slug: string): Promise<BlogPost | null> {
  const query = groq`*[_type == "blog" && slug.current == $slug][0] {
    _id,
    title,
    publishedAt,
    "coverImage": coverImage.asset->url,
    "heroImage": heroImage.asset->url,
    summary,
    content[] {
      ...,
      image { ..., asset-> },
      images[] { ..., asset-> }
    },
    likes,
    author-> {
      name,
      "image": image.asset->url,
      bio
    },
    tags
  }`;
  return await client.fetch(query, { slug });
}

async function getApprovedComments(postId: string): Promise<Comment[]> {
  const query = groq`*[_type == "comment" && post._ref == $postId && approved == true] 
    | order(_createdAt desc) {
      _id,
      name,
      comment,
      _createdAt
    }`;
  return await client.fetch(query, { postId }, { cache: "no-store" });
}

async function getFeaturedJourneys(): Promise<Journey[]> {
  return await client.fetch(
    groq`*[_type == "journey" && featuredOnHome == true][0...3] {
      _id,
      title,
      "slug": slug,
      region->{ title },
      heroImage { asset->{ url }, alt }
    }`
  );
}

async function getMostLikedBlogs(): Promise<LikedBlog[]> {
  return await client.fetch(
    groq`*[_type == "blog"] | order(likes desc, publishedAt desc)[0...3] {
      _id,
      title,
      "slug": slug,
      "coverImage": coverImage.asset->url,
      "alt": coverImage.alt,
      likes
    }`
  );
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = await getPost(slug);

  if (!post) return { title: "Not Found" };
  return {
    title: post.title,
    description: post.summary,
  };
}

export default async function BlogPost({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) return notFound();

  const comments = await getApprovedComments(post._id);
  const featuredJourneys = await getFeaturedJourneys();
  const mostLikedBlogs = await getMostLikedBlogs();

  return (
    <main className="bg-[#fdf8f3] text-black min-h-screen px-0">
      {post.heroImage && (
        <div
          className="relative w-full h-[300px] sm:h-[400px] flex items-center justify-center"
          style={{
            backgroundImage: `url(${post.heroImage})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        >
          <div className="bg-black/50 w-full h-full absolute inset-0" />
          <h1 className="relative z-10 text-3xl sm:text-5xl text-white font-bold px-4 text-center">
            {post.title}
          </h1>
        </div>
      )}

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-4 gap-10 mt-10">
        <div className="lg:col-span-3">
          <BlogContent blocks={post.content} />
          <div className="mt-6 flex flex-wrap items-center gap-4">
            <LikeButton postId={post._id} initialLikes={post.likes || 0} />
            <ShareButtons title={post.title} />
          </div>
        </div>

        <aside className="lg:col-span-1 bg-white p-6 rounded-lg shadow-sm border border-gray-200 text-center space-y-4">
          {post.author?.image && (
            <div className="flex justify-center">
              <img
                src={post.author.image}
                alt={post.author.name}
                className="w-28 h-28 rounded-full object-cover shadow-md border-2 border-amber-600"
              />
            </div>
          )}
          <div>
            <h2 className="text-xl font-semibold text-gray-900">
              {post.author?.name || "Unknown Author"}
            </h2>
            {post.author?.bio && (
              <p className="text-sm text-gray-600 mt-1">{post.author.bio}</p>
            )}
          </div>
          {Array.isArray(post.tags) && post.tags.length > 0 && (
            <div className="bg-white shadow p-4 rounded-lg">
              <h4 className="text-sm font-semibold mb-2 text-gray-800">Tags</h4>
              <ul className="flex flex-wrap gap-2">
                {post.tags.map((tag) => (
                  <li
                    key={tag}
                    className="bg-amber-600 text-white text-xs px-2 py-1 rounded-full"
                  >
                    {tag}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {featuredJourneys.length > 0 && (
            <div className="bg-[#f5f3ef] p-4 rounded-lg">
              <h4 className="text-lg font-semibold mb-3">
                🌍 Featured Journeys
              </h4>
              <ul className="space-y-4">
                {featuredJourneys.map((j) => (
                  <li
                    key={j._id}
                    className="bg-white p-2 rounded shadow flex gap-3 items-center"
                  >
                    {j.heroImage?.asset?.url && (
                      <img
                        src={j.heroImage.asset.url}
                        alt={j.heroImage.alt || j.title}
                        width={60}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                    )}
                    <div>
                      <h5 className="text-sm font-bold text-gray-800">
                        {j.title}
                      </h5>
                      {j.region?.title && (
                        <p className="text-xs text-orange-600">
                          {j.region.title}
                        </p>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {mostLikedBlogs.length > 0 && (
            <div className="bg-[#f5f3ef] p-4 rounded-lg">
              <h4 className="text-lg font-semibold mb-3">
                🔥 Most Liked Blogs
              </h4>
              <ul className="space-y-4">
                {mostLikedBlogs.map((b) => (
                  <li
                    key={b._id}
                    className="bg-white p-2 rounded shadow flex gap-3 items-center"
                  >
                    {b.coverImage && (
                      <img
                        src={b.coverImage}
                        alt={b.alt || b.title}
                        width={60}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                    )}
                    <div>
                      <h5 className="text-sm font-bold text-gray-800">
                        {b.title}
                      </h5>
                      <p className="text-xs text-gray-500 mt-1">
                        {b.likes ?? 0} likes
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </aside>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 mt-16">
        <section className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-2xl font-semibold mb-4 text-gray-900">
            Ready to share your thoughts?
          </h2>
          <p className="mb-4 text-gray-600 text-sm">
            We love hearing from mindful travelers. Leave a comment below.
          </p>
          <CommentFormWrapper postId={post._id} />
          {comments.length > 0 && (
            <div className="mt-8 space-y-6">
              <h3 className="text-lg font-semibold text-gray-800">Comments</h3>
              {comments.map((c) => (
                <div key={c._id} className="border rounded p-4 bg-gray-50">
                  <p className="text-sm font-medium text-gray-900">{c.name}</p>
                  <p className="text-sm text-gray-700 mt-1">{c.comment}</p>
                  <p className="text-xs text-gray-400 mt-2">
                    {new Date(c._createdAt).toLocaleDateString()}
                  </p>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
